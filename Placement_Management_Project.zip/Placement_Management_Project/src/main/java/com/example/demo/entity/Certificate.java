package com.example.demo.entity;

import javax.persistence.*;

@Entity
public class Certificate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int year;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id")
    private Student student;

    // Constructors
    public Certificate() {
    }

    public Certificate(Long id, int year, Student student) {
        this.id = id;
        this.year = year;
        this.student = student;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    // toString method
    @Override
    public String toString() {
        return "Certificate{" +
                "id=" + id +
                ", year=" + year +
                ", student=" + student +
                '}';
    }
}
