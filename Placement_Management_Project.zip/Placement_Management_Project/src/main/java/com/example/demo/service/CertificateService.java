package com.example.demo.service;

import com.example.demo.entity.Certificate;
import java.util.*;

public interface CertificateService {
    Certificate addCertificate(Certificate certificate);
    Certificate updateCertificate(Certificate certificate);
    Certificate getCertificateById(Long id);
    void deleteCertificate(Long id);
    List<Certificate> getAllCertificates();
}
