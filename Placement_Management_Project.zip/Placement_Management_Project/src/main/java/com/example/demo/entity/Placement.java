package com.example.demo.entity;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
public class Placement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private LocalDate date;
    private String qualification;
    private int year;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "college_id")
    private College college;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id")
    private Student student;

    // Constructors
    public Placement() {
    }

    public Placement(Long id, String name, LocalDate date, String qualification, int year, College college, Student student) {
        this.id = id;
        this.name = name;
        this.date = date;
        this.qualification = qualification;
        this.year = year;
        this.college = college;
        this.student = student;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public College getCollege() {
        return college;
    }

    public void setCollege(College college) {
        this.college = college;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    // toString method
    @Override
    public String toString() {
        return "Placement{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", date=" + date +
                ", qualification='" + qualification + '\'' +
                ", year=" + year +
                ", college=" + college +
                '}';
    }
}
