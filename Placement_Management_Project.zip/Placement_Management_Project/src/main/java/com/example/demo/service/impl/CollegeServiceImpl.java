package com.example.demo.service.impl;
import com.example.demo.exceptions.*;

import com.example.demo.entity.College;
import java.util.*;
import com.example.demo.repository.CollegeRepository;
import com.example.demo.service.CollegeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CollegeServiceImpl implements CollegeService {

    @Autowired
    private CollegeRepository collegeRepository;

    @Override
    public College addCollege(College college) {
        return collegeRepository.save(college);
    }

    @Override
    public College updateCollege(College college) {
        return collegeRepository.save(college);
    }

    @Override
    public College getCollegeById(Long id) {
        return collegeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("College not found with id: " + id));
    }
    
    @Override
    public List<College> getAllColleges() {
        return collegeRepository.findAll();
    }

    @Override
    public void deleteCollege(Long id) {
        if (!collegeRepository.existsById(id)) {
            throw new ResourceNotFoundException("College not found with id: " + id);
        }
        collegeRepository.deleteById(id);
    }
}
