package com.example.demo.service;

import com.example.demo.entity.Student;
import java.util.*;

public interface StudentService {
    Student addStudent(Student student);
    Student updateStudent(Student student);
    Student getStudentById(Long id);
    void deleteStudent(Long id);
    List<Student> getAllStudents();
}
