package com.example.demo.service;

import com.example.demo.entity.User;
import java.util.*;

public interface UserService {
    User addUser(User user);
    User updateUser(User user);
    User getUserById(Long id);
    void deleteUser(Long id);
    List<User> getAllUsers();
}
