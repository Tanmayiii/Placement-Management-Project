package com.example.demo.service;

import com.example.demo.entity.Placement;
import java.util.*;

public interface PlacementService {
    Placement addPlacement(Placement placement);
    Placement updatePlacement(Placement placement);
    Placement getPlacementById(Long id);
    void deletePlacement(Long id);
    List<Placement> getAllPlacements();
}
