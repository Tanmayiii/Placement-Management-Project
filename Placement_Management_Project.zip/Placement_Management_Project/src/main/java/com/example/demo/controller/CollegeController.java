package com.example.demo.controller;

import com.example.demo.entity.College;
import java.util.*;
import com.example.demo.service.CollegeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/colleges")
public class CollegeController {

    @Autowired
    private CollegeService collegeService;

    @PostMapping
    public ResponseEntity<College> addCollege(@RequestBody College college) {
        College createdCollege = collegeService.addCollege(college);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdCollege);
    }

    @PutMapping
    public ResponseEntity<College> updateCollege(@RequestBody College college) {
        College updatedCollege = collegeService.updateCollege(college);
        return ResponseEntity.ok(updatedCollege);
    }
    
    @GetMapping
    public ResponseEntity<List<College>> getAllColleges() {
        List<College> colleges = collegeService.getAllColleges();
        return ResponseEntity.ok(colleges);
    }

    @GetMapping("/{id}")
    public ResponseEntity<College> getCollegeById(@PathVariable Long id) {
        College college = collegeService.getCollegeById(id);
        return ResponseEntity.ok(college);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCollege(@PathVariable Long id) {
        collegeService.deleteCollege(id);
        return ResponseEntity.noContent().build();
    }
}
