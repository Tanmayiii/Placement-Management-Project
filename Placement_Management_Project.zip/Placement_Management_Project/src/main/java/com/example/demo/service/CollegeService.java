package com.example.demo.service;

import com.example.demo.entity.College;
import java.util.*;

public interface CollegeService {
    College addCollege(College college);
    College updateCollege(College college);
    College getCollegeById(Long id);
    void deleteCollege(Long id);
    List<College> getAllColleges();
}

