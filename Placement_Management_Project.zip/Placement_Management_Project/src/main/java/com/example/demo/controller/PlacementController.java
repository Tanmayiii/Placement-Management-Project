package com.example.demo.controller;

import com.example.demo.entity.Placement;
import java.util.*;
import com.example.demo.service.PlacementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/placements")
public class PlacementController {

    @Autowired
    private PlacementService placementService;

    @PostMapping
    public ResponseEntity<Placement> addPlacement(@RequestBody Placement placement) {
        Placement createdPlacement = placementService.addPlacement(placement);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdPlacement);
    }

    @PutMapping
    public ResponseEntity<Placement> updatePlacement(@RequestBody Placement placement) {
        Placement updatedPlacement = placementService.updatePlacement(placement);
        return ResponseEntity.ok(updatedPlacement);
    }
    
    @GetMapping
    public ResponseEntity<List<Placement>> getAllPlacements() {
        List<Placement> placements = placementService.getAllPlacements();
        return ResponseEntity.ok(placements);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Placement> getPlacementById(@PathVariable Long id) {
        Placement placement = placementService.getPlacementById(id);
        return ResponseEntity.ok(placement);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePlacement(@PathVariable Long id) {
        placementService.deletePlacement(id);
        return ResponseEntity.noContent().build();
    }
}
