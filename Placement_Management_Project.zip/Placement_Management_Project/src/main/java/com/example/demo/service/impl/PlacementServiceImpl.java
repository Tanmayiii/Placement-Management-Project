package com.example.demo.service.impl;
import com.example.demo.exceptions.*;


import com.example.demo.entity.Placement;
import java.util.*;
import com.example.demo.repository.PlacementRepository;
import com.example.demo.service.PlacementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PlacementServiceImpl implements PlacementService {

    @Autowired
    private PlacementRepository placementRepository;

    @Override
    public Placement addPlacement(Placement placement) {
        return placementRepository.save(placement);
    }

    @Override
    public Placement updatePlacement(Placement placement) {
        return placementRepository.save(placement);
    }

    @Override
    public Placement getPlacementById(Long id) {
        return placementRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Placement not found with id: " + id));
    }
    
    @Override
    public List<Placement> getAllPlacements() {
        return placementRepository.findAll();
    }

    @Override
    public void deletePlacement(Long id) {
        if (!placementRepository.existsById(id)) {
            throw new ResourceNotFoundException("Placement not found with id: " + id);
        }
        placementRepository.deleteById(id);
    }
}
